# DjangoRolePermissionTokenAuthorisation
Basic Role permission based token system authorisation for django.

Six Tables are used to maintain this token based role permission authorisation system.

To use this app with you django project.

Download and save the folder along side your other apps.

Run makemigrations to make the migration script and then migrate to create the desired tables.
